<?php
header("Location:view/");
error_reporting(0);
?>
<!DOCTYPE html>
<html>
<head>
	<title>HALAMAN TIDAK DITEMUKAN</title>
</head>
<body>
	<h1>HALAMAN TIDAK DITEMUKAN</h1>
	<a href="view/index.php">KEMBALI</a>
</body>
</html>