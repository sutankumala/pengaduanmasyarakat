<?php
$koneksi = mysqli_connect("localhost", "root", "", "pengaduan")
			or die("Kesalahan Pada Koneksi ke Database !");
?>